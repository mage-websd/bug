<?php
/**
 * Script to clean up product tier discordances that prevent magento from reindexing product prices
 *
 */
require( 'lib/db.php' );

$ids_tier = $db->get_col( "SELECT entity_id FROM catalog_product_entity_tier_price");

foreach ( $ids_tier as $id_tier )
{
    $id_product = '';
    $id_product = $db->get_var ( "SELECT entity_id FROM catalog_product_entity WHERE entity_id = '$id_tier'");
    
    if ( empty($id_product) )
    {
        $db->query( "DELETE FROM catalog_product_entity_tier_price WHERE entity_id = '$id_tier'" );
        echo "S'ha eliminat $id_tier"."<br/>";
    }
    
}


?>
