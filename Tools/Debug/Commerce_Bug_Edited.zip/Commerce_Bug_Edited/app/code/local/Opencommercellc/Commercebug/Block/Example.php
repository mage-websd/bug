<?php
/**
* Copyright © Pulsestorm LLC: All rights reserved
*/

class Opencommercellc_Commercebug_Block_Example extends Mage_Core_Block_Text
{
}