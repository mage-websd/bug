<?php
/**
* Copyright © Pulsestorm LLC: All rights reserved
*/

class Opencommercellc_Commercebug_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    }
}