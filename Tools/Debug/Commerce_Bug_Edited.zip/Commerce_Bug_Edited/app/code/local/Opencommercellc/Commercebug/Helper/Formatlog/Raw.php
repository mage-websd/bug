<?php
/**
* Copyright © Pulsestorm LLC: All rights reserved
*/

class Opencommercellc_Commercebug_Helper_Formatlog_Raw extends Opencommercellc_Commercebug_Helper_Data
{
    public function format($thing)
    {
        return $thing;
    }
}