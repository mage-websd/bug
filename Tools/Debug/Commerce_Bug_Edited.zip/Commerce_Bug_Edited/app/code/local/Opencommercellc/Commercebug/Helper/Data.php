<?php
/**
* Copyright © Pulsestorm LLC: All rights reserved
*/

class Opencommercellc_Commercebug_Helper_Data extends Opencommercellc_Commercebug_Helper_Abstract
{	
    public function calculateRealModuleName()
    {
        return self::_getModuleName();
    }
    
    
// 		public function __()
// 		{
// 			return '##';
// 		}
}